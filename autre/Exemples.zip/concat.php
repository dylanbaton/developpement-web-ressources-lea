<?php


$prenom="toto";
$test=["nom"=>"dupont"];

echo "bonjour $test['nom']";