<?php

$bdd = new PDO('mysql:host=localhost;dbname=testEA_promo;charset=utf8', 'root', 'root', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
// var_dump($bdd);

?>