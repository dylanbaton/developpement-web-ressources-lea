<form action="traitementInsert.php" method="GET">

    Nom
    <input type="text" name="nom">

    <br>

    Prenom
    <input type="text" name="prenom">

    <br>

    <input type="submit">

</form>