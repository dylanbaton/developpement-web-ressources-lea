<form action="traitementDelete.php" action="get">

id à supprimer
<input type="text" name="id">

<input type="submit">

</form>