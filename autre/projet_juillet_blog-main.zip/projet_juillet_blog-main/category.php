<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="insertion.php" method="GET">
            <select name="categorie" id="categorie">
                <option value="categorie">Categorie</option>
                <option value="automobile">Automobile</option>
                <option value="dinosaure">Dinosaure</option>
                <!-- <option value="outils">Outils</option> -->
            </select>
            <input type="submit" value="vaider">
        </form>
</body>
</html>